# Smart Waste Management System — Phase 1 (SWMS-2026-P1)
### Bin Fill-Level Monitoring & Alert Module — Prototype Build Documentation

**Client:** Municipal Waste Corporation (Pilot Site)
**Scope:** Single-site, dual-bin (Organic + Dry) monitoring unit, WiFi-connected, cloud-synced, real-time alerting.
**Phase:** 1 — Prototype

---

## 1. System Architecture Overview

The system continuously measures the fill level of two waste bins (organic and dry) at a single site using ultrasonic distance sensors. An ESP32 microcontroller reads both sensors, computes fill percentage, and pushes readings to a cloud database. A separate alert engine monitors the cloud data and notifies the municipal corporation when a bin crosses a configured fill threshold.

**Data flow:**

```
[HC-SR04 Sensor: Organic] --\
                              >--> [ESP32 MCU] --(WiFi/HTTPS)--> [Firebase Realtime DB]
[HC-SR04 Sensor: Dry]      --/                                          |
                                                                          v
                                                          [Python Alert Engine (polling)]
                                                                          |
                                                          +---------------+---------------+
                                                          |                               |
                                                    [Twilio SMS]                   [SMTP Email]
                                                                          |
                                                                [Dashboard / Web View]
```

**Component list:**

| Component | Role |
|---|---|
| ESP32 Dev Board | Central MCU — sensor reading, WiFi, cloud upload, sleep management |
| HC-SR04 x2 | Distance sensing for organic and dry bins |
| Firebase Realtime DB | Cloud data store for live bin readings |
| Python Alert Engine | Polls DB, applies threshold logic, dispatches alerts |
| Twilio (optional) | SMS notification channel |
| SMTP (Gmail) | Free email notification channel |
| Power source | USB/power bank in prototype; solar + battery at scale |

---

## 2. Hardware Wiring Specification

**Pin mapping — ESP32 ↔ HC-SR04 (Organic bin):**

| HC-SR04 Pin | ESP32 GPIO |
|---|---|
| VCC | 5V |
| GND | GND |
| TRIG | GPIO 5 |
| ECHO | GPIO 18 |

**Pin mapping — ESP32 ↔ HC-SR04 (Dry bin):**

| HC-SR04 Pin | ESP32 GPIO |
|---|---|
| VCC | 5V |
| GND | GND |
| TRIG | GPIO 19 |
| ECHO | GPIO 21 |

**Power distribution notes:**
- HC-SR04 operates at 5V; ESP32 logic is 3.3V. The ECHO pin outputs 5V — for a durable build, use a voltage divider (1kΩ/2kΩ) on each ECHO line to protect the ESP32 GPIO. Skipped in this prototype for speed, but flagged for hardening before field deployment.
- Common ground between ESP32 and both sensors is mandatory.
- Typical current draw: ESP32 ~80-240mA active, HC-SR04 ~15mA each. A standard 5V/1A USB source or power bank is sufficient for prototype testing.

**ASCII wiring diagram:**

```
                +---------------------+
                |        ESP32        |
                |                     |
   Organic  ----| GPIO5  (TRIG)       |
   Sensor   ----| GPIO18 (ECHO)       |
                |                     |
   Dry      ----| GPIO19 (TRIG)       |
   Sensor   ----| GPIO21 (ECHO)       |
                |                     |
                |  5V   GND           |
                +---+-----+-----------+
                    |     |
              (shared 5V and GND rail to both HC-SR04 sensors)
```

**Mounting notes:**
- Mount each sensor at the center of the bin lid, facing straight down.
- Keep the sensor face clear of lid hinges/obstructions — false readings occur if the sensor's beam cone (~15°) hits the bin wall instead of the waste surface.
- Measure and record actual `BIN_HEIGHT_CM` (sensor face to bin floor) per bin — this is a config value in the firmware, not hardcoded logic.

---

## 3. Firmware Summary

See `firmware/SWMS_P1_firmware.ino` for the complete, ready-to-flash code.

**Key design points:**
- `readSensor()` — single ultrasonic pulse/echo measurement.
- `getAveragedDistance()` — 5-sample averaging, discarding failed reads, to reduce noise (debounce).
- `calculateFillPercent()` — converts distance to 0–100% fill using configured bin height.
- `sendToCloud()` — builds JSON payload and PUTs it to Firebase per bin.
- Deep sleep between cycles (30s in testing config; change `SLEEP_INTERVAL_SEC` to 900 for 15-minute production cycles).

**Before flashing, update in the CONFIG block:**
- `WIFI_SSID`, `WIFI_PASSWORD`
- `FIREBASE_HOST` (your project's database URL)
- `BIN_HEIGHT_CM` (measured per bin)
- `SITE_ID`

---

## 4. Cloud Database Setup (Firebase)

1. Go to [Firebase Console](https://console.firebase.google.com) → **Add Project** → name it (e.g., `swms-project`).
2. In the left menu, go to **Build → Realtime Database → Create Database**.
3. Choose a region close to your deployment site (e.g., asia-southeast1 for India).
4. Start in **test mode** for prototype development (open read/write) — you'll see a warning; that's expected at this phase.
5. Copy your database URL — it looks like:
   `https://swms-project-default-rtdb.asia-southeast1.firebasedatabase.app`
   Paste this into `FIREBASE_HOST` in the firmware and `alert_engine.py`.

**JSON schema (matches firmware payload):**

```json
{
  "readings": {
    "SITE_001": {
      "organic": {
        "site_id": "SITE_001",
        "bin_type": "organic",
        "fill_percent": 42,
        "timestamp": 1732789200,
        "alert_triggered": false,
        "device_status": "online"
      },
      "dry": {
        "site_id": "SITE_001",
        "bin_type": "dry",
        "fill_percent": 85,
        "timestamp": 1732789200,
        "alert_triggered": true,
        "device_status": "online"
      }
    }
  }
}
```

**Security rules — testing mode (prototype only):**
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

**Security rules — production-hardened (apply before real deployment):**
```json
{
  "rules": {
    "readings": {
      "$site_id": {
        ".read": "auth != null",
        ".write": "auth != null"
      }
    }
  }
}
```
The difference: test-mode rules allow anyone with the database URL to read/write, which is fine for a closed prototype demo but unsafe in the field. Production rules require Firebase Authentication (or a database secret) before accepting requests.

**Example curl test (verify manually before trusting firmware):**
```bash
curl -X PUT -d '{"site_id":"SITE_001","bin_type":"organic","fill_percent":42,"timestamp":1732789200,"alert_triggered":false,"device_status":"online"}' \
  "https://YOUR_PROJECT_ID-default-rtdb.firebaseio.com/readings/SITE_001/organic.json"
```

---

## 5. Alert Engine Summary

See `alert_engine/alert_engine.py` for the complete, ready-to-run code.

**Key design points:**
- `BinStateMachine` — tracks per-bin state (`NORMAL` → `ALERT_SENT` → reset on empty) so the same full bin doesn't trigger repeated alerts every poll cycle.
- `AlertDispatcher` — sends SMS via Twilio (optional, disabled by default) and/or email via SMTP (enabled by default, free).
- All alerts are logged to `alert_log.csv` with timestamp, site, bin type, fill %, and action taken.

**SMTP setup (Gmail, free):**
1. Enable 2-Step Verification on the sending Gmail account.
2. Generate an **App Password** (Google Account → Security → App Passwords).
3. Use that app password in `SMTP_PASSWORD` (not your real Gmail password).

**Twilio setup (optional, SMS):**
1. Create a free trial account at twilio.com.
2. Get `ACCOUNT_SID`, `AUTH_TOKEN`, and a trial phone number.
3. Set `TWILIO_ENABLED = True` and fill in credentials.
4. Note: Twilio trial accounts can only send to verified numbers until upgraded.

---

## 6. Validation & QA Checklist

| # | Test | Method | Pass Criteria |
|---|---|---|---|
| 1 | Sensor accuracy | Measure known distance with ruler, compare to Serial Monitor output | Within ±2cm |
| 2 | Fill % calculation | Place object at known height, verify calculated % | Matches expected % ±5% |
| 3 | WiFi connectivity | Power on device, check Serial log | Connects within 10s, prints IP |
| 4 | Cloud sync | Check Firebase console after upload | Reading appears within 5s of upload |
| 5 | Alert trigger (organic) | Manually raise organic fill above threshold | SMS/email received within 1 poll cycle |
| 6 | Alert trigger (dry) | Manually raise dry fill above threshold | SMS/email received within 1 poll cycle |
| 7 | De-duplication | Keep bin full across multiple poll cycles | Only ONE alert sent until bin emptied |
| 8 | Reset behavior | Empty bin after alert, refill later | New alert fires on next threshold breach |
| 9 | False positive rate | Run system for 2 hours idle | Zero spurious alerts |
| 10 | CSV logging | Check `alert_log.csv` after test alerts | All alerts logged with correct fields |

---

## 7. Troubleshooting & Runbook

| Issue | Likely Cause | Resolution |
|---|---|---|
| Sensor reads 0 or -1 | Loose wiring, sensor out of range, obstruction | Recheck TRIG/ECHO wiring; ensure object within 2cm–4m range |
| Erratic/jumpy readings | Electrical noise, sensor angle off-center | Increase `SAMPLE_COUNT`; ensure sensor faces straight down |
| WiFi won't connect | Wrong SSID/password, weak signal, 5GHz network (ESP32 needs 2.4GHz) | Verify credentials; confirm router broadcasts 2.4GHz |
| Firebase "permission denied" | Security rules too strict for test mode, wrong auth token | Confirm test-mode rules are applied, or pass correct `FIREBASE_AUTH` |
| No data in Firebase console | Wrong `FIREBASE_HOST` URL, device not connected | Verify URL has no typo/trailing slash mismatch; check Serial log for HTTP code |
| Alert not firing | `FILL_THRESHOLD` mismatch between firmware and alert engine, poll interval too long | Ensure both configs use same threshold value; reduce `POLL_INTERVAL_SEC` for testing |
| Duplicate alerts every cycle | State machine not resetting, bin never reported below threshold | Check `BinStateMachine` logic; confirm sensor reads valid data after bin emptied |
| ESP32 keeps restarting | Insufficient power (brownout), especially when both sensors trigger together | Use a stable 5V/1A+ power source; add slight delay between sensor triggers |

---

## 8. Deployment Notes for Scale-Up

This prototype targets a single site with two bins. For multi-site rollout:

- **Device provisioning:** Assign a unique `SITE_ID` per unit at flash time; consider a provisioning script that writes site config via a config file or Bluetooth pairing instead of hardcoding.
- **Fleet management:** Move from a single Firebase path per site to a structured fleet registry (`/devices/{device_id}/status`) tracking battery level, last-seen timestamp, and firmware version for remote health monitoring.
- **Power upgrade path:** Replace USB power with a solar panel (6–9V) + Li-ion battery (18650) + TP4056 charge controller + buck converter to regulate to ESP32's 5V input. Deep sleep interval should move to 900s+ to extend battery life.
- **Connectivity fallback:** For sites with unreliable WiFi, add a GSM module (SIM800L) as a fallback data path, or evaluate LoRaWAN for long-range, low-power multi-site coverage.
- **Enclosure:** Move to an IP65-rated weatherproof enclosure with cable glands for sensor leads before any outdoor field deployment.
- **Security hardening:** Switch Firebase rules to authenticated access (Section 4) before connecting any unit outside a controlled test environment.
