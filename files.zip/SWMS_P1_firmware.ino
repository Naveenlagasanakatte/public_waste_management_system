/*
  ============================================================================
  Project      : Smart Waste Management System (SWMS-2026-P1)
  Module       : Bin Fill-Level Sensing & Cloud Reporting Firmware
  Target MCU   : ESP32 Dev Board
  Sensors      : 2x HC-SR04 Ultrasonic Distance Sensor
                 (Sensor A = Organic Bin, Sensor B = Dry Waste Bin)
  Cloud Target : Firebase Realtime Database (REST API over HTTPS)
  Author       : SWMS Engineering (Prototype Phase)
  ============================================================================

  FUNCTIONAL OVERVIEW
  --------------------
  1. Reads distance from two ultrasonic sensors (organic + dry bins).
  2. Converts distance -> fill percentage using configured bin height.
  3. Applies 5-sample averaging to reduce sensor noise (debounce).
  4. Compares fill percentage against FILL_THRESHOLD.
  5. Builds a JSON payload per bin and POSTs it to Firebase via HTTPS.
  6. Sleeps for SLEEP_INTERVAL seconds (deep sleep) to conserve power,
     then repeats.

  NOTE (Prototype phase): SLEEP_INTERVAL is set low (30s) for live testing.
  For field deployment, change to 900 (15 min) or higher — see Section 8
  of the project documentation for the scale-up guidance.
  ============================================================================
*/

#include <WiFi.h>
#include <HTTPClient.h>

// ---------------------------------------------------------------------------
// CONFIGURATION BLOCK — adjust per site before flashing
// ---------------------------------------------------------------------------
const char* WIFI_SSID        = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD    = "YOUR_WIFI_PASSWORD";

// Firebase Realtime Database REST endpoint (no trailing slash), e.g.:
// https://swms-project-default-rtdb.asia-southeast1.firebasedatabase.app
const char* FIREBASE_HOST    = "https://YOUR_PROJECT_ID-default-rtdb.firebaseio.com";
const char* FIREBASE_AUTH    = "";   // leave blank in testing mode; add DB secret for production

const char* SITE_ID          = "SITE_001";
const float BIN_HEIGHT_CM    = 50.0;   // empty-bin distance (sensor to bin floor)
const int   FILL_THRESHOLD   = 80;     // percent, triggers alert flag
const int   SAMPLE_COUNT     = 5;      // readings averaged per cycle
const uint64_t SLEEP_INTERVAL_SEC = 30; // testing value; use 900 for production

// GPIO pin mapping — see wiring spec in docs/wiring_and_architecture.md
const int TRIG_ORGANIC = 5;
const int ECHO_ORGANIC = 18;
const int TRIG_DRY     = 19;
const int ECHO_DRY     = 21;

// ---------------------------------------------------------------------------
// STRUCT: holds one bin's computed reading
// ---------------------------------------------------------------------------
struct BinReading {
  const char* binType;
  float distanceCm;
  int fillPercent;
  bool alertTriggered;
};

// ---------------------------------------------------------------------------
// FUNCTION: readSensor()
// Triggers an HC-SR04 pulse and returns the measured distance in cm.
// ---------------------------------------------------------------------------
float readSensor(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH, 30000); // 30ms timeout ~5m max range
  if (duration == 0) {
    return -1.0; // no echo received — sensor fault or out of range
  }
  float distanceCm = duration * 0.0343 / 2.0;
  return distanceCm;
}

// ---------------------------------------------------------------------------
// FUNCTION: getAveragedDistance()
// Takes SAMPLE_COUNT readings and returns the mean, ignoring failed reads.
// ---------------------------------------------------------------------------
float getAveragedDistance(int trigPin, int echoPin) {
  float sum = 0;
  int validSamples = 0;

  for (int i = 0; i < SAMPLE_COUNT; i++) {
    float d = readSensor(trigPin, echoPin);
    if (d > 0) {
      sum += d;
      validSamples++;
    }
    delay(60); // small gap between pulses to avoid cross-echo interference
  }

  if (validSamples == 0) return -1.0;
  return sum / validSamples;
}

// ---------------------------------------------------------------------------
// FUNCTION: calculateFillPercent()
// Converts a distance reading into a 0-100 fill percentage.
// ---------------------------------------------------------------------------
int calculateFillPercent(float distanceCm) {
  if (distanceCm < 0) return -1; // sensor error passthrough

  float fill = ((BIN_HEIGHT_CM - distanceCm) / BIN_HEIGHT_CM) * 100.0;
  if (fill < 0) fill = 0;
  if (fill > 100) fill = 100;
  return (int)fill;
}

// ---------------------------------------------------------------------------
// FUNCTION: buildBinReading()
// Wraps sensing + calculation for one bin into a single reading struct.
// ---------------------------------------------------------------------------
BinReading buildBinReading(const char* binType, int trigPin, int echoPin) {
  BinReading r;
  r.binType = binType;
  r.distanceCm = getAveragedDistance(trigPin, echoPin);
  r.fillPercent = calculateFillPercent(r.distanceCm);
  r.alertTriggered = (r.fillPercent >= FILL_THRESHOLD);

  Serial.printf("[SENSOR] %s -> distance=%.2fcm fill=%d%% alert=%s\n",
                binType, r.distanceCm, r.fillPercent,
                r.alertTriggered ? "YES" : "no");
  return r;
}

// ---------------------------------------------------------------------------
// FUNCTION: connectWiFi()
// Connects to WiFi with a bounded retry loop.
// ---------------------------------------------------------------------------
bool connectWiFi() {
  Serial.printf("[WIFI] Connecting to %s ...\n", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("[WIFI] Connected. IP: %s\n", WiFi.localIP().toString().c_str());
    return true;
  } else {
    Serial.println("[WIFI] FAILED to connect.");
    return false;
  }
}

// ---------------------------------------------------------------------------
// FUNCTION: sendToCloud()
// Builds the JSON payload for one bin reading and POSTs it to Firebase.
// Firebase REST convention: PUT/POST to <host>/path.json
// ---------------------------------------------------------------------------
void sendToCloud(BinReading r) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[CLOUD] Skipped — WiFi not connected.");
    return;
  }

  HTTPClient http;
  String path = String(FIREBASE_HOST) + "/readings/" + String(SITE_ID) +
                "/" + String(r.binType) + ".json";
  if (strlen(FIREBASE_AUTH) > 0) {
    path += "?auth=" + String(FIREBASE_AUTH);
  }

  http.begin(path);
  http.addHeader("Content-Type", "application/json");

  String payload = "{";
  payload += "\"site_id\":\"" + String(SITE_ID) + "\",";
  payload += "\"bin_type\":\"" + String(r.binType) + "\",";
  payload += "\"fill_percent\":" + String(r.fillPercent) + ",";
  payload += "\"timestamp\":" + String((unsigned long)time(nullptr)) + ",";
  payload += "\"alert_triggered\":" + String(r.alertTriggered ? "true" : "false") + ",";
  payload += "\"device_status\":\"online\"";
  payload += "}";

  int httpCode = http.PUT(payload); // PUT overwrites latest reading per bin

  if (httpCode > 0) {
    Serial.printf("[CLOUD] %s upload OK, HTTP %d\n", r.binType, httpCode);
  } else {
    Serial.printf("[CLOUD] %s upload FAILED: %s\n", r.binType,
                  http.errorToString(httpCode).c_str());
  }
  http.end();
}

// ---------------------------------------------------------------------------
// SETUP
// ---------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("\n[BOOT] SWMS-2026-P1 firmware starting...");

  pinMode(TRIG_ORGANIC, OUTPUT);
  pinMode(ECHO_ORGANIC, INPUT);
  pinMode(TRIG_DRY, OUTPUT);
  pinMode(ECHO_DRY, INPUT);

  bool wifiOk = connectWiFi();

  BinReading organic = buildBinReading("organic", TRIG_ORGANIC, ECHO_ORGANIC);
  BinReading dry      = buildBinReading("dry", TRIG_DRY, ECHO_DRY);

  if (wifiOk) {
    sendToCloud(organic);
    sendToCloud(dry);
  }

  Serial.printf("[POWER] Entering deep sleep for %llu seconds...\n", SLEEP_INTERVAL_SEC);
  Serial.flush();

  esp_sleep_enable_timer_wakeup(SLEEP_INTERVAL_SEC * 1000000ULL);
  esp_deep_sleep_start();
  // Execution restarts from setup() after wake — ESP32 deep sleep resets the chip.
}

void loop() {
  // Intentionally empty — deep sleep cycle restarts setup() on wake.
}
