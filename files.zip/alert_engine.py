"""
============================================================================
Project   : Smart Waste Management System (SWMS-2026-P1)
Module    : Alert Engine Microservice
Purpose   : Polls Firebase Realtime Database for bin fill readings,
            detects threshold breaches, and dispatches alerts via
            SMS (Twilio) and/or email (SMTP), with de-duplication
            and CSV audit logging.
============================================================================

USAGE
-----
1. pip install requests twilio  (twilio optional if only using email)
2. Fill in the CONFIG section below.
3. Run: python alert_engine.py
"""

import csv
import os
import smtplib
import time
from datetime import datetime
from email.mime.text import MIMEText

import requests

# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------
FIREBASE_HOST = "https://YOUR_PROJECT_ID-default-rtdb.firebaseio.com"
FIREBASE_AUTH = ""  # DB secret, leave blank in testing mode

SITE_ID = "SITE_001"
BIN_TYPES = ["organic", "dry"]
FILL_THRESHOLD = 80
POLL_INTERVAL_SEC = 20

# --- Twilio (SMS) ---
TWILIO_ENABLED = False
TWILIO_ACCOUNT_SID = "YOUR_TWILIO_SID"
TWILIO_AUTH_TOKEN = "YOUR_TWILIO_AUTH_TOKEN"
TWILIO_FROM_NUMBER = "+1XXXXXXXXXX"
TWILIO_TO_NUMBER = "+91XXXXXXXXXX"

# --- SMTP (Email, free fallback) ---
SMTP_ENABLED = True
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USERNAME = "your_email@gmail.com"
SMTP_PASSWORD = "your_app_password"   # use an app password, not your real password
ALERT_EMAIL_TO = "municipal.corp@example.com"

LOG_FILE = os.path.join(os.path.dirname(__file__), "alert_log.csv")


# ---------------------------------------------------------------------------
# CLASS: BinStateMachine
# Tracks per-bin alert state to prevent duplicate alerts:
#   NORMAL -> ALERT_SENT -> (stays ALERT_SENT until fill drops below
#   threshold) -> RESET back to NORMAL
# ---------------------------------------------------------------------------
class BinStateMachine:
    def __init__(self):
        self.state = {}  # key: f"{site_id}_{bin_type}" -> "NORMAL" | "ALERT_SENT"

    def should_alert(self, key, fill_percent, threshold):
        current = self.state.get(key, "NORMAL")

        if fill_percent >= threshold and current == "NORMAL":
            self.state[key] = "ALERT_SENT"
            return True  # new breach — fire alert

        if fill_percent < threshold and current == "ALERT_SENT":
            self.state[key] = "NORMAL"  # bin emptied, reset for next cycle

        return False  # either already alerted, or still under threshold


# ---------------------------------------------------------------------------
# CLASS: AlertDispatcher
# Handles sending notifications through configured channels.
# ---------------------------------------------------------------------------
class AlertDispatcher:
    def __init__(self):
        self.twilio_client = None
        if TWILIO_ENABLED:
            from twilio.rest import Client
            self.twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

    def send_sms(self, message):
        if not TWILIO_ENABLED or self.twilio_client is None:
            return False
        try:
            self.twilio_client.messages.create(
                body=message, from_=TWILIO_FROM_NUMBER, to=TWILIO_TO_NUMBER
            )
            print("[ALERT][SMS] Sent successfully.")
            return True
        except Exception as e:
            print(f"[ALERT][SMS] Failed: {e}")
            return False

    def send_email(self, subject, message):
        if not SMTP_ENABLED:
            return False
        try:
            msg = MIMEText(message)
            msg["Subject"] = subject
            msg["From"] = SMTP_USERNAME
            msg["To"] = ALERT_EMAIL_TO

            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                server.starttls()
                server.login(SMTP_USERNAME, SMTP_PASSWORD)
                server.send_message(msg)
            print("[ALERT][EMAIL] Sent successfully.")
            return True
        except Exception as e:
            print(f"[ALERT][EMAIL] Failed: {e}")
            return False

    def dispatch(self, site_id, bin_type, fill_percent):
        subject = f"SWMS Alert: {bin_type.upper()} bin full at {site_id}"
        message = (
            f"Site {site_id} — {bin_type} waste bin is at {fill_percent}% capacity "
            f"(threshold breached). Please schedule collection."
        )
        sms_sent = self.send_sms(message)
        email_sent = self.send_email(subject, message)
        return sms_sent or email_sent


# ---------------------------------------------------------------------------
# FUNCTION: log_alert()
# Appends an alert record to the CSV audit log.
# ---------------------------------------------------------------------------
def log_alert(site_id, bin_type, fill_percent, action_taken):
    file_exists = os.path.isfile(LOG_FILE)
    with open(LOG_FILE, mode="a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["timestamp", "site_id", "bin_type", "fill_percent", "action_taken"])
        writer.writerow([datetime.now().isoformat(), site_id, bin_type, fill_percent, action_taken])


# ---------------------------------------------------------------------------
# FUNCTION: fetch_reading()
# Pulls the latest reading for one bin from Firebase REST API.
# ---------------------------------------------------------------------------
def fetch_reading(site_id, bin_type):
    url = f"{FIREBASE_HOST}/readings/{site_id}/{bin_type}.json"
    if FIREBASE_AUTH:
        url += f"?auth={FIREBASE_AUTH}"
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"[POLL] Failed to fetch {bin_type} reading: {e}")
        return None


# ---------------------------------------------------------------------------
# MAIN LOOP
# ---------------------------------------------------------------------------
def main():
    print("[BOOT] SWMS Alert Engine starting...")
    print(f"[CONFIG] Site: {SITE_ID} | Threshold: {FILL_THRESHOLD}% | Poll every {POLL_INTERVAL_SEC}s")

    state_machine = BinStateMachine()
    dispatcher = AlertDispatcher()

    while True:
        for bin_type in BIN_TYPES:
            data = fetch_reading(SITE_ID, bin_type)
            if not data or "fill_percent" not in data:
                continue

            fill_percent = data["fill_percent"]
            key = f"{SITE_ID}_{bin_type}"
            print(f"[POLL] {bin_type} -> {fill_percent}%")

            if state_machine.should_alert(key, fill_percent, FILL_THRESHOLD):
                sent = dispatcher.dispatch(SITE_ID, bin_type, fill_percent)
                action = "ALERT_SENT" if sent else "ALERT_FAILED"
                log_alert(SITE_ID, bin_type, fill_percent, action)

        time.sleep(POLL_INTERVAL_SEC)


if __name__ == "__main__":
    main()
